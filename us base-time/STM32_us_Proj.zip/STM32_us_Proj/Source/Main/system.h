#ifndef __SYSTEM_H__
#define __SYSTEM_H__



void SysInit(void);//ϵͳ��ʼ��



#endif


