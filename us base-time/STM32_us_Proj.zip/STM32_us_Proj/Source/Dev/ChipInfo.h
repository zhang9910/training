#ifndef __CHIPINFO_H__
#define __CHIPINFO_H__

void GetChipID(void);
void GetFlashCapacity(void);

#endif
