#ifndef __BSP_TIMER__H__
#define __BSP_TIMER__H__




void Tim2Init(int prescaler,int period);




#endif

