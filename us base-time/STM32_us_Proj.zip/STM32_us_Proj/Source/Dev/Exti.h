#ifndef  __EXTI_H__
#define  __EXTI_H__



void ExtiInit(void);

#endif

